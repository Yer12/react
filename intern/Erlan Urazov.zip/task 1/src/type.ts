class TodoItem{
    constructor (public title: string, public subtitle: string){}
}
class ListTemplate {
    constructor(private container: HTMLUListElement) { }
    render(item: TodoItem){
        const li = document.createElement('li');
        li.innerText = `${item.title}-${item.subtitle}`
        this.container.append(li);
    }
}
const f = document.querySelector("#form") as HTMLFormElement;
const ul = document.querySelector('ul')!
const list = new ListTemplate(ul);
const t = document.querySelector('#title') as HTMLInputElement;
const s = document.querySelector('#subtitle') as HTMLInputElement;
f.addEventListener('submit', (e: Event) => {
    e.preventDefault();
    const itemTodo: TodoItem = new TodoItem(t.value, s.value);
    list.render(itemTodo);
});
