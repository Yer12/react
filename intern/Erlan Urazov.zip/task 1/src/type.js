"use strict";
class TodoItem {
    constructor(title, subtitle) {
        this.title = title;
        this.subtitle = subtitle;
    }
}
class ListTemplate {
    constructor(container) {
        this.container = container;
    }
    render(item) {
        const li = document.createElement('li');
        li.innerText = `${item.title}-${item.subtitle}`;
        this.container.append(li);
    }
}
const f = document.querySelector("#form");
const ul = document.querySelector('ul');
const list = new ListTemplate(ul);
const t = document.querySelector('#title');
const s = document.querySelector('#subtitle');
f.addEventListener('submit', (e) => {
    e.preventDefault();
    const itemTodo = new TodoItem(t.value, s.value);
    list.render(itemTodo);
});
