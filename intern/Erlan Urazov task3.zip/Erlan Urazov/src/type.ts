class TodoItem{
    constructor (public id: number, public title: string, public subtitle: string){}
}
class ListTemplate {
    constructor(public container: HTMLUListElement) { }
    // @ts-ignore
    // @ts-ignore
    render(item: TodoItem){

        const taskItem = `
            <li data-task-id="${item.id}" class="content__data__item item">
                ${item.title} - ${item.subtitle} 
                <button class="btn btn-success" id="edit" data-id="${item.id}" title="">Edit</button>
                <button class="btn btn-danger" id="delete" data-id="${item.id}" title="">Delete</button>
            </li>`;
        this.container.innerHTML += (`${taskItem}`);
        // @ts-ignore
        document.querySelector('#delete').addEventListener('click', ()=>{
            confirm("Are you sure delete this item?");
        });
        // @ts-ignore
        document.querySelector('#edit').addEventListener('click', () => {

            // @ts-ignore
            modal.style.display = "block";
            // @ts-ignore
            cont.classList.add("opc");
        });
        // @ts-ignore
        document.querySelector('#close').addEventListener( 'click',() => {
            // @ts-ignore
            modal.style.display = "none";
            // @ts-ignore
            cont.classList.remove("opc");
        });
    }

}
const modal = document.getElementById('editModal');
const cont = document.getElementById('cont');
const f = document.querySelector("#form") as HTMLFormElement;
const ul = document.querySelector('ul')!
const list = new ListTemplate(ul);
const t = document.querySelector('#title') as HTMLInputElement;
const s = document.querySelector('#subtitle') as HTMLInputElement;

f.addEventListener('submit', (e: Event) => {
    e.preventDefault();
    const itemTodo: TodoItem = new TodoItem((list.container.children.length), t.value, s.value);
    list.render(itemTodo);
});




